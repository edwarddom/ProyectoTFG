<?php

namespace CommerceGuys\Intl\Exception;

interface ExceptionInterface
{
}
